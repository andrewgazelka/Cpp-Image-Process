#pragma once


#include "pixel.h"

class Vec3D {

public:
    Vec3D(float x, float y, float z) : x(x), y(y), z(z) {}

    Vec3D(): x(0.0), y(0.0), z(0.0) {}

    static Vec3D fromPixel(Pixel &pixel) {
        return {(float) pixel.r, (float) pixel.g , (float) pixel.b};
    }

    Pixel toPixel() {
        Pixel pixel;
        pixel.SetClamp(x , y, z );
        return pixel;
    }

    float x, y, z;

    Vec3D operator+(Vec3D const &other) const {
        return {x + other.x, y + other.y, z + other.z};
    }

    Vec3D operator*(double const &other) const {
        return Vec3D(x * other, y * other, z * other);
    }

    Vec3D operator-(Vec3D const &other) const {
        return {x - other.x, y - other.y, z - other.z};
    }
};

 
