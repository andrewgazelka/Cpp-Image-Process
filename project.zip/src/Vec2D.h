#pragma once

#include <cmath>

class Vec2D {
public:
    Vec2D(const double x, const double y): x(x), y(y){}

    Vec2D() : x(0), y(0) {}

    double mag2() const {
        return x * x + y * y;
    }

    double mag() const {
        return sqrt(mag2());
    }

    Vec2D operator+(Vec2D const &other) const {
        return {x + other.x, y + other.y};
    }

    Vec2D operator*(double const &other) const {
        return {x * other, y * other};
    }

    Vec2D operator/(double const &other) const {
        return {x / other, y / other};
    }

    Vec2D operator-(Vec2D const &other) const {
        return {x - other.x, y - other.y};
    }

    Vec2D rotate(const double theta) const {

        const double c = cos(theta);
        const double s = sin(theta);

        const double newX = x * c - y * s;
        const double newY = x * s + y * c;

        return {newX, newY};
    }

    const double x, y;
};

 
