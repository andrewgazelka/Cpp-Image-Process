#pragma once


#include "Vec3D.h"
#include "image.h"

class FloatImg {
public:
    virtual ~FloatImg() {
        delete[] data;
    }

    FloatImg(int width, int height) : width(width), height(height) {
        data = new Vec3D[width * height];
    }

    void applyImage(Image& image){
        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                image.GetPixel(x,y) = getOrNull(x,y)->toPixel();
            }
        }
    }

    static FloatImg fromImg(const Image &image) {
        auto img = FloatImg(image.width, image.height);
        for (int x = 0; x < image.width; ++x) {
            for (int y = 0; y < image.height; ++y) {
                auto pixel = image.GetPixel(x, y);
                *img.getOrNull(x, y) = Vec3D::fromPixel(pixel);
            }
        }
        return img;
    }

    Vec3D *getOrNull(int x, int y) {
        if (x < 0 || x > width) return nullptr;
        if (y < 0 || y > height) return nullptr;
        return &data[x + y * width];
    }

private:
    Vec3D *data;
    int width;
    int height;
};

 
